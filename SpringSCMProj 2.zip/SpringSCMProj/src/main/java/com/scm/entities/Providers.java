package com.scm.entities;

public enum Providers {
    SELf, GOOGLE, GITHUB

}

