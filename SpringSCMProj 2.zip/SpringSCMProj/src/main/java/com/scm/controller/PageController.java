package com.scm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestMethod;
// import org.springframework.web.bind.annotation.RequestMetho
import org.springframework.web.bind.annotation.RequestMethod;

import com.scm.entities.User;
import com.scm.forms.Userform;
import com.scm.helpers.Message;
import com.scm.helpers.MessageType;
import com.scm.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class PageController {

    @Autowired
    private UserService userService;

    @RequestMapping("/")
    public String index() {
        return "redirect:/home";
    }
    @RequestMapping("/home")
    public String home() {
        return "home";
    }

    @RequestMapping("/about")
    public String aboutPage() {
        return "about";
    }

    @RequestMapping("/services")
    public String servicePage() {
        return "services";
    }

    @RequestMapping("/contact")
    public String Contact() {
        return "contact";
    }

    @RequestMapping("/login")
    public String loginPage() {
        return "login";
    }

    @RequestMapping("/signup")
    public String signUpPage(Model model) {
        Userform userform = new Userform();
        model.addAttribute("userform", userform);
        return "signup";
    }

    // Processing register
    @RequestMapping(value = "/do-register", method = RequestMethod.POST)
    public String processRegister(@Valid @ModelAttribute Userform userform, BindingResult rBindingResult, HttpSession session) {
        // We have to fetch and validate and then save the form data
        if(rBindingResult.hasErrors()){
            System.out.println("Im working");
            return "signup";
        }

        // We also have to show message: Registration Succesfull

        // database


        //userService
        // User user = User.builder()
        // .name(userform.getName())
        // .email(userform.getEmail())
        // .password(userform.getPassword())
        // .about(userform.getAbout())
        // .phone(userform.getPhonenumber())
        // .profilePic("https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.vecteezy.com%2Ffree-vector%2Fdefault-profile-picture&psig=AOvVaw3-_J2DPVpPYNuv3_rczD-s&ust=1723396948320000&source=images&cd=vfe&opi=89978449&ved=2ahUKEwisgciI-OqHAxUqRmwGHVg1AI8QjRx6BAgAEBU")
        // .build();
        User user = new User();
        user.setName(userform.getName());
        user.setEmail(userform.getEmail());
        user.setPassword(userform.getPassword());
        user.setAbout(userform.getAbout());
        user.setPhone(userform.getPhone());
        user.setEnabled(false);
        user.setProfilePic("https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.vecteezy.com%2Ffree-vector%2Fdefault-profile-picture&psig=AOvVaw3-_J2DPVpPYNuv3_rczD-s&ust=1723396948320000&source=images&cd=vfe&opi=89978449&ved=2ahUKEwisgciI-OqHAxUqRmwGHVg1AI8QjRx6BAgAEBU");
        User saveUser = userService.saveUser(user);

        //add the message
        Message message = Message.builder().content("Registration Successfull").type(MessageType.green).build();
        session.setAttribute("message", message);

        System.out.println(userform);
        return "redirect:/signup";
    }

}
