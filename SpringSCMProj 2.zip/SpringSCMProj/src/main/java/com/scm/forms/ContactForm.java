package com.scm.forms;

import org.springframework.web.multipart.MultipartFile;

import com.scm.validators.ValidFile;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ContactForm {

    @NotBlank(message = "Name is requried")
    private String name;

    @NotBlank(message = "Email is reqruired")
    @Email(message = "Invalid email address")
    private String email;

    @NotBlank(message = "Phone Number is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Invalid Phone Number")
    private String phone;

    @NotBlank(message = "Address is required")
    private String address;

    private String description;

    private boolean favourite;

    private String websiteLink;

    private String linkedinLink;


    @ValidFile
    private MultipartFile profilepic;

    private String picture;

}
