console.log("script added");
let current_theme ="light";

document.addEventListener("DOMContentLoaded",()=>{
    changeTheme();
})

function changeTheme(){
    document.querySelector('html').classList.add(current_theme);
    const changeThemeButton = document.querySelector('#change_theme');
    changeThemeButton.addEventListener('click', (event)=>{
        const oldTheme = current_theme;
    if(current_theme=="dark"){
        current_theme = "light";
    }
    else{
        current_theme = "dark";
    }

    setTheme(current_theme);

    document.querySelector('html').classList.remove(oldTheme);
    document.querySelector('html').classList.add(current_theme);
    });
}
// Set theme to local storage 
function setTheme(theme) {
    localStorage.setItem("theme", theme);

    
    
}

// Get theme from local storage

function getTheme(){

    let theme = localStorage.getItem("theme");
    return theme? theme : "light";
}